import pool from "../configs/database/db.js";
import { DateTime } from "luxon";

const PERIODS = new Set([
  "this_month",
  "this_year",
  "last_7_days",
  "last_30_days",
  "last_month",
  "last_year",
]);

const dateRange = (period, timezone) => {
  const now = DateTime.now().setZone(timezone);
  if (!now.isValid) {
    const error = new Error("Invalid timezone.");
    error.statusCode = 400;
    throw error;
  }

  let start;
  let end;
  let previousStart;
  let previousEnd;

  switch (period) {
    case "this_year":
      start = now.startOf("year");
      end = now;
      previousStart = start.minus({ years: 1 });
      previousEnd = end.minus({ years: 1 });
      break;
    case "last_7_days":
      end = now.startOf("day");
      start = end.minus({ days: 6 });
      previousEnd = start.minus({ days: 1 });
      previousStart = previousEnd.minus({ days: 6 });
      break;
    case "last_30_days":
      end = now.startOf("day");
      start = end.minus({ days: 29 });
      previousEnd = start.minus({ days: 1 });
      previousStart = previousEnd.minus({ days: 29 });
      break;
    case "last_month":
      start = now.minus({ months: 1 }).startOf("month");
      end = now.minus({ months: 1 }).endOf("month");
      previousStart = start.minus({ months: 1 }).startOf("month");
      previousEnd = start.minus({ days: 1 }).endOf("day");
      break;
    case "last_year":
      start = now.minus({ years: 1 }).startOf("year");
      end = now.minus({ years: 1 }).endOf("year");
      previousStart = start.minus({ years: 1 });
      previousEnd = end.minus({ years: 1 });
      break;
    case "this_month":
    default:
      start = now.startOf("month");
      end = now;
      previousStart = start.minus({ months: 1 }).startOf("month");
      previousEnd = start.minus({ days: 1 }).endOf("day");
      break;
  }

  return {
    start: start.toISODate(),
    end: end.toISODate(),
    previousStart: previousStart.toISODate(),
    previousEnd: previousEnd.toISODate(),
    days: Math.max(1, Math.round(end.startOf("day").diff(start.startOf("day"), "days").days) + 1),
  };
};

const percentChange = (current, previous) => {
  const currentValue = Number(current || 0);
  const previousValue = Number(previous || 0);

  if (previousValue === 0) {
    return currentValue === 0 ? 0 : null;
  }

  return Number((((currentValue - previousValue) / previousValue) * 100).toFixed(2));
};

const numeric = (value) => Number(value || 0);

const getBusinessContext = async (userId, requestedBusinessId) => {
  const [businesses] = await pool.execute(
    `
      SELECT id, name, business_name, country_code, admin_area_1, city, area, is_selected
      FROM business_details
      WHERE user_id = ?
        AND is_deleted = 0
      ORDER BY is_selected DESC, id DESC
    `,
    [userId],
  );

  if (businesses.length === 0) {
    const error = new Error("No business details found for this account.");
    error.statusCode = 404;
    throw error;
  }

  let business;
  if (requestedBusinessId) {
    business = businesses.find((item) => Number(item.id) === Number(requestedBusinessId));
    if (!business) {
      const error = new Error("Business not found or does not belong to the authenticated user.");
      error.statusCode = 404;
      throw error;
    }
  } else {
    business = businesses.find((item) => Number(item.is_selected) === 1) || businesses[0];
  }

  return { businesses, business };
};

const getSpendTotals = async (userId, businessId, start, end) => {
  const [rows] = await pool.execute(
    `
      SELECT
        currency_code,
        COALESCE(SUM(impressions), 0) AS impressions,
        COALESCE(SUM(clicks), 0) AS clicks,
        COALESCE(SUM(total_charge), 0) AS amount_spent
      FROM ad_campaign_daily_spend
      WHERE user_id = ?
        AND business_id = ?
        AND campaign_local_date BETWEEN ? AND ?
      GROUP BY currency_code
      ORDER BY currency_code
    `,
    [userId, businessId, start, end],
  );

  return rows.map((row) => ({
    currency: row.currency_code,
    impressions: numeric(row.impressions),
    clicks: numeric(row.clicks),
    amount_spent: Number(numeric(row.amount_spent).toFixed(6)),
  }));
};

const getDashboardOverview = async ({
  userId,
  businessId,
  overviewPeriod = "this_month",
  spendPeriod = "this_year",
  timezone = "Asia/Kolkata",
  topLimit = 5,
}) => {
  if (!PERIODS.has(overviewPeriod) || !PERIODS.has(spendPeriod)) {
    const error = new Error("Invalid dashboard period.");
    error.statusCode = 400;
    throw error;
  }

  const { businesses, business } = await getBusinessContext(userId, businessId);
  const overviewRange = dateRange(overviewPeriod, timezone);
  const spendRange = dateRange(spendPeriod, timezone);

  const [
    overviewTotals,
    previousTotals,
    campaignRows,
    spendRows,
    topCampaignRows,
  ] = await Promise.all([
    getSpendTotals(userId, business.id, overviewRange.start, overviewRange.end),
    getSpendTotals(userId, business.id, overviewRange.previousStart, overviewRange.previousEnd),
    pool.execute(
      `
        SELECT
          COUNT(*) AS total_campaigns,
          SUM(CASE WHEN a.moderation_status = 'under_review' THEN 1 ELSE 0 END) AS under_verify,
          SUM(CASE WHEN a.moderation_status <> 'under_review' AND c.status = 'active' THEN 1 ELSE 0 END) AS active,
          SUM(CASE WHEN a.moderation_status <> 'under_review' AND c.status = 'completed' THEN 1 ELSE 0 END) AS completed,
          SUM(CASE WHEN a.moderation_status <> 'under_review' AND c.status = 'paused' THEN 1 ELSE 0 END) AS paused,
          SUM(CASE WHEN a.moderation_status <> 'under_review' AND c.status = 'draft' THEN 1 ELSE 0 END) AS draft
        FROM ad_campaigns c
        INNER JOIN ads a
          ON a.campaign_id = c.id
          AND a.user_id = c.user_id
        WHERE c.user_id = ?
          AND c.business_id = ?
          AND c.is_deleted = 0
          AND a.is_deleted = 0
      `,
      [userId, business.id],
    ),
    pool.execute(
      `
        SELECT
          DATE_FORMAT(campaign_local_date, '%Y-%m-%d') AS campaign_local_date,
          currency_code,
          COALESCE(SUM(total_charge), 0) AS amount_spent,
          COALESCE(SUM(impressions), 0) AS impressions,
          COALESCE(SUM(clicks), 0) AS clicks
        FROM ad_campaign_daily_spend
        WHERE user_id = ?
          AND business_id = ?
          AND campaign_local_date BETWEEN ? AND ?
        GROUP BY campaign_local_date, currency_code
        ORDER BY campaign_local_date ASC, currency_code ASC
      `,
      [userId, business.id, spendRange.start, spendRange.end],
    ),
    pool.execute(
      `
        SELECT
          c.id AS campaign_id,
          a.id AS ad_id,
          a.title,
          a.description,
          a.status AS ad_status,
          a.moderation_status,
          a.objective_id,
          o.name AS objective_name,
          (
            SELECT media.file_url
            FROM ad_media media
            WHERE media.ad_id = a.id
              AND media.is_active = 1
              AND media.media_type = 'image'
            ORDER BY media.sort_order ASC, media.id ASC
            LIMIT 1
          ) AS image_url,
          COALESCE(SUM(ds.impressions), 0) AS impressions,
          COALESCE(SUM(ds.clicks), 0) AS clicks,
          COALESCE(SUM(ds.total_charge), 0) AS amount_spent,
          MAX(ds.currency_code) AS currency
        FROM ad_campaigns c
        INNER JOIN ads a
          ON a.campaign_id = c.id
          AND a.user_id = c.user_id
        LEFT JOIN ad_objectives o
          ON o.id = a.objective_id
        LEFT JOIN ad_campaign_daily_spend ds
          ON ds.campaign_id = c.id
          AND ds.ad_id = a.id
          AND ds.user_id = c.user_id
          AND ds.business_id = c.business_id
          AND ds.campaign_local_date BETWEEN ? AND ?
        WHERE c.user_id = ?
          AND c.business_id = ?
          AND c.is_deleted = 0
          AND a.is_deleted = 0
        GROUP BY
          c.id, a.id, a.title, a.description, a.status,
          a.moderation_status, a.objective_id, o.name
        HAVING
          SUM(COALESCE(ds.impressions, 0)) > 0
          OR SUM(COALESCE(ds.clicks, 0)) > 0
          OR SUM(COALESCE(ds.total_charge, 0)) > 0
        ORDER BY impressions DESC, clicks DESC, amount_spent DESC, c.id DESC
        LIMIT ?
      `,
      [overviewRange.start, overviewRange.end, userId, business.id, topLimit],
    ),
  ]);

  const overview = overviewTotals;
  const previous = previousTotals;
  const currentImpressions = overview.reduce((sum, row) => sum + row.impressions, 0);
  const currentClicks = overview.reduce((sum, row) => sum + row.clicks, 0);
  const previousImpressions = previous.reduce((sum, row) => sum + row.impressions, 0);
  const previousClicks = previous.reduce((sum, row) => sum + row.clicks, 0);

  const currencies = [...new Set(overview.map((row) => row.currency))];
  const previousCurrencies = [...new Set(previous.map((row) => row.currency))];
  const amountSpent = currencies.length <= 1
    ? Number(overview.reduce((sum, row) => sum + row.amount_spent, 0).toFixed(6))
    : null;
  const previousAmountSpent = previousCurrencies.length <= 1
    ? Number(previous.reduce((sum, row) => sum + row.amount_spent, 0).toFixed(6))
    : null;

  const [campaignCountRows] = campaignRows;
  const campaignCount = campaignCountRows[0] || {
    total_campaigns: 0,
    active: 0,
    completed: 0,
    paused: 0,
    draft: 0,
    under_verify: 0,
  };
  const [dailyRows] = spendRows;
  const [topRows] = topCampaignRows;

  const bucketByMonth = spendPeriod === "this_year" || spendPeriod === "last_year";
  const chartMap = new Map();

  for (const row of dailyRows) {
    const key = bucketByMonth
      ? String(row.campaign_local_date).slice(0, 7)
      : String(row.campaign_local_date).slice(0, 10);
    const mapKey = `${key}:${row.currency_code}`;
    const existing = chartMap.get(mapKey) || {
      period: key,
      currency: row.currency_code,
      amount_spent: 0,
      impressions: 0,
      clicks: 0,
    };
    existing.amount_spent += numeric(row.amount_spent);
    existing.impressions += numeric(row.impressions);
    existing.clicks += numeric(row.clicks);
    chartMap.set(mapKey, existing);
  }

  const spendCurrencies = [...new Set(dailyRows.map((row) => row.currency_code))];
  const chartCurrencies = spendCurrencies.length ? spendCurrencies : [...new Set(overview.map((row) => row.currency))];
  const chartStart = DateTime.fromISO(spendRange.start, { zone: timezone });
  const chartEnd = DateTime.fromISO(spendRange.end, { zone: timezone });
  const chartData = [];

  for (
    let cursor = chartStart;
    cursor <= chartEnd;
    cursor = bucketByMonth ? cursor.plus({ months: 1 }).startOf("month") : cursor.plus({ days: 1 })
  ) {
    const key = bucketByMonth ? cursor.toFormat("yyyy-MM") : cursor.toISODate();
    for (const currency of chartCurrencies) {
      const row = chartMap.get(`${key}:${currency}`);
      chartData.push({
        period: key,
        currency,
        amount_spent: row ? Number(row.amount_spent.toFixed(6)) : 0,
        impressions: row ? row.impressions : 0,
        clicks: row ? row.clicks : 0,
      });
    }
  }

  const spendCurrencyTotals = spendCurrencies.map((currency) => {
    const rows = dailyRows.filter((row) => row.currency_code === currency);
    return {
      currency,
      amount_spent: Number(rows.reduce((sum, row) => sum + numeric(row.amount_spent), 0).toFixed(6)),
    };
  });

  return {
    businesses: businesses.map(({ id, name, business_name, country_code, admin_area_1, city, area, is_selected }) => ({
      id: Number(id),
      name,
      business_name,
      country_code,
      admin_area_1,
      city,
      area,
      is_selected: Boolean(Number(is_selected)),
    })),
    selected_business: {
      id: Number(business.id),
      name: business.name,
      business_name: business.business_name,
      country_code: business.country_code,
      admin_area_1: business.admin_area_1,
      city: business.city,
      area: business.area,
    },
    filters: {
      overview_period: overviewPeriod,
      spend_period: spendPeriod,
      timezone,
      overview: overviewRange,
      spend: spendRange,
    },
    quick_overview: {
      total_impressions: currentImpressions,
      total_clicks: currentClicks,
      total_amount_spent: amountSpent,
      currency: currencies.length === 1 ? currencies[0] : null,
      currency_totals: overview,
      comparison: {
        impressions_percent: percentChange(currentImpressions, previousImpressions),
        clicks_percent: percentChange(currentClicks, previousClicks),
        amount_spent_percent:
          amountSpent !== null &&
          previousAmountSpent !== null &&
          currencies.join(",") === previousCurrencies.join(",")
            ? percentChange(amountSpent, previousAmountSpent)
            : null,
        previous_period: {
          start_date: overviewRange.previousStart,
          end_date: overviewRange.previousEnd,
          total_impressions: previousImpressions,
          total_clicks: previousClicks,
          total_amount_spent: previousAmountSpent,
          currency: previousCurrencies.length === 1 ? previousCurrencies[0] : null,
          currency_totals: previous,
        },
      },
    },
    campaign_performance: {
      total_campaigns: numeric(campaignCount.total_campaigns),
      active: numeric(campaignCount.active),
      completed: numeric(campaignCount.completed),
      paused: numeric(campaignCount.paused),
      draft: numeric(campaignCount.draft),
      under_verify: numeric(campaignCount.under_verify),
    },
    spend_overview: {
      total_amount_spent: spendCurrencies.length <= 1
        ? Number(dailyRows.reduce((sum, row) => sum + numeric(row.amount_spent), 0).toFixed(6))
        : null,
      currency: spendCurrencies.length === 1 ? spendCurrencies[0] : null,
      currency_totals: spendCurrencyTotals,
      bucket: bucketByMonth ? "month" : "day",
      chart_data: chartData,
    },
    top_performing_campaigns: topRows.map((row) => ({
      campaign_id: Number(row.campaign_id),
      ad_id: Number(row.ad_id),
      title: row.title,
      description: row.description,
      image_url: row.image_url,
      objective_id: Number(row.objective_id),
      objective_name: row.objective_name,
      status: row.ad_status,
      moderation_status: row.moderation_status,
      impressions: numeric(row.impressions),
      clicks: numeric(row.clicks),
      amount_spent: Number(numeric(row.amount_spent).toFixed(6)),
      currency: row.currency,
    })),
  };
};

export default { getDashboardOverview };
