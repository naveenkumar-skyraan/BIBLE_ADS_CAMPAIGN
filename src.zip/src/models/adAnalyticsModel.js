import crypto from "node:crypto";
import pool from "../configs/database/db.js";
import { DateTime } from "luxon";
import {
  decimalToMicros,
  microsToDecimal,
  calculateAdSpend,
} from "../utils/adSpendCalculator.js";

const createError = (message, statusCode = 400) => {
  const error = new Error(message);
  error.statusCode = statusCode;
  return error;
};

const getPayloadHash = (payload) => {
  const canonicalPayload = {
    platform: payload.platform,
    app_instance_id: payload.app_instance_id || null,
    app_version: payload.app_version || null,
    interval_start: payload.interval_start,
    interval_end: payload.interval_end,
    items: [...payload.items]
      .map(({ ad_id, impressions, clicks }) => ({
        ad_id,
        impressions,
        clicks,
      }))
      .sort((a, b) => a.ad_id - b.ad_id),
  };

  return crypto
    .createHash("sha256")
    .update(JSON.stringify(canonicalPayload))
    .digest("hex");
};

const getCampaignLocalDate = (intervalStart, intervalEnd, timezone) => {
  const start = DateTime.fromSeconds(Number(intervalStart), {
    zone: timezone,
  });

  const end = DateTime.fromSeconds(Number(intervalEnd) - 1, {
    zone: timezone,
  });

  if (!start.isValid || !end.isValid) {
    throw createError("Invalid analytics interval or campaign timezone.");
  }

  if (start.toISODate() !== end.toISODate()) {
    throw createError(
      "Analytics intervals crossing campaign-local midnight must be split into separate batches.",
    );
  }

  return start.toISODate();
};

const getNextLocalMidnight = (localDate, timezone) => {
  return Math.floor(
    DateTime.fromISO(localDate, { zone: timezone })
      .plus({ days: 1 })
      .startOf("day")
      .toUTC()
      .toSeconds(),
  );
};

const persistRejectedBatch = async (
  connection,
  payload,
  payloadHash,
  reason,
) => {
  const [result] = await connection.execute(
    `
      INSERT INTO ad_analytics_batches (
        batch_id,
        platform,
        app_instance_id,
        app_version,
        interval_start,
        interval_end,
        payload_hash,
        processing_status,
        rejection_reason,
        rejection_payload
      )
      VALUES (?, ?, ?, ?, ?, ?, ?, 'rejected', ?, ?)
    `,
    [
      payload.batch_id,
      payload.platform,
      payload.app_instance_id || null,
      payload.app_version || null,
      payload.interval_start,
      payload.interval_end,
      payloadHash,
      reason,
      JSON.stringify(payload),
    ],
  );

  return result.insertId;
};

const getExistingBatch = async (batchId) => {
  const [rows] = await pool.execute(
    `
      SELECT
        id,
        payload_hash,
        processing_status,
        rejection_reason
      FROM ad_analytics_batches
      WHERE batch_id = ?
      LIMIT 1
    `,
    [batchId],
  );

  return rows[0] || null;
};

const pauseCampaign = async (
  connection,
  { campaignId, adId, reason, pausedAt, resumeAt = null },
) => {
  const [result] = await connection.execute(
    `
      UPDATE ad_campaigns
      SET
        status = 'paused',
        pause_reason = ?,
        resume_at = ?,
        paused_at = ?,
        updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
        AND status = 'active'
        AND is_deleted = 0
    `,
    [reason, resumeAt, pausedAt, campaignId],
  );

  if (result.affectedRows === 0) {
    return false;
  }

  await connection.execute(
    `
      UPDATE ads
      SET
        status = 'paused',
        updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
        AND status = 'active'
        AND is_deleted = 0
    `,
    [adId],
  );

  await connection.execute(
    `
      INSERT INTO ad_campaign_pause_history (
        campaign_id,
        ad_id,
        pause_reason,
        paused_at
      )
      VALUES (?, ?, ?, ?)
    `,
    [campaignId, adId, reason, pausedAt],
  );

  return true;
};

const completeCampaignForBudget = async (
  connection,
  campaignId,
  adId,
  stoppedAt,
) => {
  const [result] = await connection.execute(
    `
      UPDATE ad_campaigns
      SET
        status = 'completed',
        pause_reason = NULL,
        resume_at = NULL,
        paused_at = NULL,
        billing_stopped_at = ?,
        updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
        AND status IN ('active', 'paused')
        AND is_deleted = 0
    `,
    [stoppedAt, campaignId],
  );

  if (result.affectedRows > 0) {
    await connection.execute(
      `
        UPDATE ads
        SET
          status = 'completed',
          updated_at = CURRENT_TIMESTAMP
        WHERE id = ?
          AND status IN ('active', 'paused')
          AND is_deleted = 0
      `,
      [adId],
    );
  }
};

const pauseAllUserCampaignsForWallet = async (connection, userId, pausedAt) => {
  await connection.execute(
    `
      UPDATE ad_campaigns
      SET
        status = 'paused',
        pause_reason = 'wallet_insufficient',
        resume_at = NULL,
        paused_at = ?,
        updated_at = CURRENT_TIMESTAMP
      WHERE user_id = ?
        AND status = 'active'
        AND is_deleted = 0
    `,
    [pausedAt, userId],
  );

  await connection.execute(
    `
      UPDATE ads a
      INNER JOIN ad_campaigns c
        ON c.id = a.campaign_id
        AND c.user_id = a.user_id
      SET
        a.status = 'paused',
        a.updated_at = CURRENT_TIMESTAMP
      WHERE a.user_id = ?
        AND a.status = 'active'
        AND a.is_deleted = 0
        AND c.is_deleted = 0
        AND c.status = 'paused'
        AND c.pause_reason = 'wallet_insufficient'
        AND c.paused_at = ?
    `,
    [userId, pausedAt],
  );

  await connection.execute(
    `
      INSERT INTO ad_campaign_pause_history (
        campaign_id,
        ad_id,
        pause_reason,
        paused_at
      )
      SELECT
        c.id,
        a.id,
        'wallet_insufficient',
        c.paused_at
      FROM ad_campaigns c
      INNER JOIN ads a
        ON a.campaign_id = c.id
        AND a.user_id = c.user_id
      WHERE c.user_id = ?
        AND c.is_deleted = 0
        AND a.is_deleted = 0
        AND c.status = 'paused'
        AND c.pause_reason = 'wallet_insufficient'
        AND c.paused_at = ?
        AND NOT EXISTS (
          SELECT 1
          FROM ad_campaign_pause_history h
          WHERE h.campaign_id = c.id
            AND h.ad_id = a.id
            AND h.resumed_at IS NULL
        )
    `,
    [userId, pausedAt],
  );
};

export const processAdAnalyticsBatch = async (payload) => {
  const payloadHash = getPayloadHash(payload);

  const sortedItems = [...payload.items].sort((a, b) => a.ad_id - b.ad_id);

  const connection = await pool.getConnection();

  try {
    await connection.beginTransaction();

    const [existingBatches] = await connection.execute(
      `
        SELECT
          id,
          payload_hash,
          processing_status,
          rejection_reason
        FROM ad_analytics_batches
        WHERE batch_id = ?
        LIMIT 1
        FOR UPDATE
      `,
      [payload.batch_id],
    );

    if (existingBatches.length > 0) {
      const existing = existingBatches[0];

      await connection.rollback();

      if (existing.payload_hash !== payloadHash) {
        throw createError(
          "This batch_id has already been used with a different payload.",
          409,
        );
      }

      return {
        duplicate: true,
        rejected: existing.processing_status === "rejected",
        batch_id: payload.batch_id,
        rejection_reason: existing.rejection_reason || null,
        message:
          existing.processing_status === "rejected"
            ? "This analytics batch was previously rejected."
            : "This analytics batch was already processed.",
      };
    }

    const preparedItems = [];
    const walletBalances = new Map();
    const dailyPending = new Map();
    const lifetimePending = new Map();

    for (const item of sortedItems) {
      const [adRows] = await connection.execute(
        `
          SELECT
            a.id AS ad_id,
            a.campaign_id,
            a.user_id,
            a.business_id,
            a.platform AS ad_platform,
            a.status AS ad_status,
            a.moderation_status,
            a.is_deleted AS ad_is_deleted,

            c.status AS campaign_status,
            c.is_deleted AS campaign_is_deleted,
            c.budget_type,
            c.total_budget,
            c.daily_budget,
            c.start_timestamp,
            c.end_timestamp,
            c.timezone,
            c.paused_at,
            c.billing_stopped_at,

            b.country_code,

            w.id AS wallet_id,
            w.balance AS wallet_balance,

            cp.currency_code,
            cp.cpm_rate,
            cp.cpc_rate

          FROM ads a

          INNER JOIN ad_campaigns c
            ON c.id = a.campaign_id
            AND c.user_id = a.user_id

          INNER JOIN business_details b
            ON b.id = a.business_id
            AND b.user_id = a.user_id
            AND b.is_deleted = 0

          INNER JOIN wallets w
            ON w.user_id = a.user_id

          INNER JOIN ad_campaign_pricing cp
            ON cp.campaign_id = c.id
            AND cp.ad_id = a.id
            AND cp.platform = ?

          WHERE a.id = ?
          LIMIT 1
          FOR UPDATE
        `,
        [payload.platform, item.ad_id],
      );

      if (adRows.length === 0) {
        throw createError(
          `Ad ${item.ad_id} is not configured for ${payload.platform.toUpperCase()}, or its campaign, wallet, business, or pricing snapshot is missing.`,
          404,
        );
      }

      const ad = adRows[0];

      const adIsDeleted = Number(ad.ad_is_deleted) === 1;
      const campaignIsDeleted = Number(ad.campaign_is_deleted) === 1;

      if (adIsDeleted !== campaignIsDeleted) {
        throw createError(
          `Ad ${item.ad_id} and its campaign have inconsistent deletion state.`,
          409,
        );
      }

      if (adIsDeleted && !ad.billing_stopped_at) {
        throw createError(
          `Ad ${item.ad_id} was deleted without a recorded billing-stop time.`,
          409,
        );
      }

      if (
        adIsDeleted &&
        Number(payload.interval_end) > Number(ad.billing_stopped_at)
      ) {
        throw createError(
          `Analytics interval for ad ${item.ad_id} extends beyond its cancellation time.`,
          409,
        );
      }

      const allowedPlatforms =
        ad.ad_platform === "both" ? ["android", "ios"] : [ad.ad_platform];

      if (!allowedPlatforms.includes(payload.platform)) {
        throw createError(
          `Ad ${item.ad_id} is not eligible for ${payload.platform.toUpperCase()}.`,
          409,
        );
      }

      if (ad.moderation_status !== "none") {
        throw createError(
          `Ad ${item.ad_id} is blocked or under moderation.`,
          409,
        );
      }

      if (
        !["active", "paused", "completed"].includes(ad.ad_status) ||
        !["active", "paused", "completed"].includes(ad.campaign_status)
      ) {
        throw createError(
          `Ad ${item.ad_id} or its campaign has not been published.`,
          409,
        );
      }

      if (
        !ad.start_timestamp ||
        !ad.end_timestamp ||
        Number(payload.interval_start) < Number(ad.start_timestamp) ||
        Number(payload.interval_end) - 1 > Number(ad.end_timestamp)
      ) {
        throw createError(
          `Analytics interval for ad ${item.ad_id} is outside its campaign schedule.`,
          409,
        );
      }

      if (
        ad.campaign_status === "paused" &&
        ad.paused_at &&
        Number(payload.interval_end) > Number(ad.paused_at)
      ) {
        throw createError(
          `Analytics interval for ad ${item.ad_id} extends beyond its campaign pause time.`,
          409,
        );
      }

      if (
        ad.billing_stopped_at &&
        Number(payload.interval_end) > Number(ad.billing_stopped_at)
      ) {
        throw createError(
          `Analytics interval for ad ${item.ad_id} extends beyond its billing-stop time.`,
          409,
        );
      }

      const [pauseWindows] = await connection.execute(
        `
          SELECT id
          FROM ad_campaign_pause_history
          WHERE campaign_id = ?
            AND ad_id = ?
            AND paused_at < ?
            AND (
              resumed_at IS NULL
              OR resumed_at > ?
            )
          LIMIT 1
          FOR UPDATE
        `,
        [
          ad.campaign_id,
          item.ad_id,
          payload.interval_end,
          payload.interval_start,
        ],
      );

      if (pauseWindows.length > 0) {
        throw createError(
          `Analytics interval for ad ${item.ad_id} overlaps a campaign pause period.`,
          409,
        );
      }

      const localDate = getCampaignLocalDate(
        payload.interval_start,
        payload.interval_end,
        ad.timezone,
      );

      const [overlappingIntervals] = await connection.execute(
        `
          SELECT id
          FROM ad_analytics_batch_items
          WHERE platform = ?
            AND ad_id = ?
            AND interval_start < ?
            AND interval_end > ?
          LIMIT 1
          FOR UPDATE
        `,
        [
          payload.platform,
          item.ad_id,
          payload.interval_end,
          payload.interval_start,
        ],
      );

      if (overlappingIntervals.length > 0) {
        throw createError(
          `An overlapping analytics interval already exists for ad ${item.ad_id} on ${payload.platform}.`,
          409,
        );
      }

      const charges = calculateAdSpend({
        impressions: item.impressions,
        clicks: item.clicks,
        cpmRate: ad.cpm_rate,
        cpcRate: ad.cpc_rate,
      });

      const walletId = Number(ad.wallet_id);
      const campaignId = Number(ad.campaign_id);

      const walletBefore = walletBalances.has(walletId)
        ? walletBalances.get(walletId)
        : decimalToMicros(ad.wallet_balance);

      const walletAfter = walletBefore - charges.walletDebitMicros;

      const dailyKey = `${campaignId}:${localDate}`;
      const pendingDaily = dailyPending.get(dailyKey) || 0n;

      const lifetimeKey = String(campaignId);
      const pendingLifetime = lifetimePending.get(lifetimeKey) || 0n;

      const [dailyRows] = await connection.execute(
        `
          SELECT COALESCE(SUM(total_charge), 0) AS spent
          FROM ad_campaign_daily_spend
          WHERE campaign_id = ?
            AND campaign_local_date = ?
        `,
        [campaignId, localDate],
      );

      const [lifetimeRows] = await connection.execute(
        `
          SELECT COALESCE(SUM(total_charge), 0) AS spent
          FROM ad_campaign_daily_spend
          WHERE campaign_id = ?
        `,
        [campaignId],
      );

      const dailySpent = decimalToMicros(dailyRows[0].spent);
      const lifetimeSpent = decimalToMicros(lifetimeRows[0].spent);

      const dailyBudget =
        ad.daily_budget === null ? null : decimalToMicros(ad.daily_budget);

      const totalBudget = decimalToMicros(ad.total_budget);

      const dailyTotalAfter = dailySpent + pendingDaily + charges.totalMicros;

      const lifetimeTotalAfter =
        lifetimeSpent + pendingLifetime + charges.totalMicros;

      if (dailyBudget !== null && dailyTotalAfter > dailyBudget) {
        const resumeAt = getNextLocalMidnight(localDate, ad.timezone);

        if (!adIsDeleted) {
          await pauseCampaign(connection, {
            campaignId,
            adId: item.ad_id,
            reason: "daily_budget",
            pausedAt: Number(payload.interval_start),
            resumeAt,
          });
        }

        const rejectedBatchId = await persistRejectedBatch(
          connection,
          payload,
          payloadHash,
          "daily_budget_exceeded",
        );

        await connection.commit();

        return {
          rejected: true,
          batch_id: payload.batch_id,
          batch_record_id: rejectedBatchId,
          reason: "daily_budget_exceeded",
          message: adIsDeleted
            ? "The batch exceeds the campaign daily budget and was rejected. The cancelled campaign was not modified."
            : "The batch exceeds the campaign daily budget. The campaign was paused until the next campaign-local day.",
          ad_id: item.ad_id,
          ...(!adIsDeleted ? { resume_at: resumeAt } : {}),
        };
      }

      if (lifetimeTotalAfter > totalBudget) {
        if (!adIsDeleted) {
          await completeCampaignForBudget(
            connection,
            campaignId,
            item.ad_id,
            Number(payload.interval_start),
          );
        }

        const rejectedBatchId = await persistRejectedBatch(
          connection,
          payload,
          payloadHash,
          "lifetime_budget_exceeded",
        );

        await connection.commit();

        return {
          rejected: true,
          batch_id: payload.batch_id,
          batch_record_id: rejectedBatchId,
          reason: "lifetime_budget_exceeded",
          message: adIsDeleted
            ? "The batch exceeds the campaign total budget and was rejected. The cancelled campaign was not modified."
            : "The batch exceeds the campaign total budget. The campaign was completed.",
          ad_id: item.ad_id,
        };
      }

      if (walletBefore < charges.walletDebitMicros) {
        if (!adIsDeleted) {
          await pauseCampaign(connection, {
            campaignId,
            adId: item.ad_id,
            reason: "wallet_insufficient",
            pausedAt: Number(payload.interval_start),
          });
        }

        const rejectedBatchId = await persistRejectedBatch(
          connection,
          payload,
          payloadHash,
          "wallet_insufficient",
        );

        await connection.commit();

        return {
          rejected: true,
          batch_id: payload.batch_id,
          batch_record_id: rejectedBatchId,
          reason: "wallet_insufficient",
          message: adIsDeleted
            ? "The wallet does not have enough balance to process this delayed batch. The cancelled campaign was not modified."
            : "The wallet does not have enough balance. The campaign was paused.",
          ad_id: item.ad_id,
          available_balance: microsToDecimal(walletBefore),
          required_amount: microsToDecimal(charges.walletDebitMicros),
        };
      }

      walletBalances.set(walletId, walletAfter);

      dailyPending.set(dailyKey, pendingDaily + charges.totalMicros);

      lifetimePending.set(lifetimeKey, pendingLifetime + charges.totalMicros);

      preparedItems.push({
        ...item,
        ad,
        localDate,
        charges,
        walletBefore,
        walletAfter,
        dailyTotalAfter,
        lifetimeTotalAfter,
      });
    }

    const [batchResult] = await connection.execute(
      `
        INSERT INTO ad_analytics_batches (
          batch_id,
          platform,
          app_instance_id,
          app_version,
          interval_start,
          interval_end,
          payload_hash,
          processing_status
        )
        VALUES (?, ?, ?, ?, ?, ?, ?, 'processed')
      `,
      [
        payload.batch_id,
        payload.platform,
        payload.app_instance_id || null,
        payload.app_version || null,
        payload.interval_start,
        payload.interval_end,
        payloadHash,
      ],
    );

    const batchRecordId = batchResult.insertId;

    const processedItems = [];
    let totalBatchCharge = 0n;
    let totalBatchWalletDebit = 0n;
    let totalBatchPlatformFee = 0n;
    let totalBatchGst = 0n;

    for (const prepared of preparedItems) {
      const { ad, localDate, charges } = prepared;

      const [itemResult] = await connection.execute(
        `
          INSERT INTO ad_analytics_batch_items (
            batch_record_id,
            platform,
            ad_id,
            campaign_id,
            business_id,
            user_id,
            wallet_id,
            interval_start,
            interval_end,
            campaign_local_date,
            impressions,
            clicks,
            currency_code,
            cpm_rate_applied,
            cpc_rate_applied,
            impression_charge,
            click_charge,
            total_charge
          )
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        `,
        [
          batchRecordId,
          payload.platform,
          prepared.ad_id,
          ad.campaign_id,
          ad.business_id,
          ad.user_id,
          ad.wallet_id,
          payload.interval_start,
          payload.interval_end,
          localDate,
          prepared.impressions,
          prepared.clicks,
          ad.currency_code,
          ad.cpm_rate,
          ad.cpc_rate,
          microsToDecimal(charges.impressionMicros),
          microsToDecimal(charges.clickMicros),
          microsToDecimal(charges.totalMicros),
        ],
      );

      const itemRecordId = itemResult.insertId;

      totalBatchCharge += charges.totalMicros;
      totalBatchWalletDebit += charges.walletDebitMicros;
      totalBatchPlatformFee += charges.platformFeeMicros;
      totalBatchGst += charges.gstMicros;

      if (charges.walletDebitMicros > 0n) {
        const [walletUpdate] = await connection.execute(
          `
            UPDATE wallets
            SET
              balance = ?,
              updated_at = CURRENT_TIMESTAMP
            WHERE id = ?
              AND balance = ?
          `,
          [
            microsToDecimal(prepared.walletAfter),
            ad.wallet_id,
            microsToDecimal(prepared.walletBefore),
          ],
        );

        if (walletUpdate.affectedRows !== 1) {
          throw createError(
            "Wallet balance changed during analytics processing. Retry the batch.",
            409,
          );
        }

        await connection.execute(
          `
            INSERT INTO wallet_transactions (
              wallet_id,
              user_id,
              business_id,
              campaign_id,
              transaction_type,
              transaction_direction,
              amount,
              ad_spend_amount,
              platform_fee,
              gst_amount,
              balance_before,
              balance_after,
              reference_id,
              reference_type,
              description
            )
            VALUES (
              ?, ?, ?, ?,
              'ad_spend',
              'debit',
              ?, ?, ?, ?, ?, ?,
              ?,
              'ad_analytics_batch_item',
              ?
            )
          `,
          [
            ad.wallet_id,
            ad.user_id,
            ad.business_id,
            ad.campaign_id,
            microsToDecimal(charges.walletDebitMicros),
            microsToDecimal(charges.totalMicros),
            microsToDecimal(charges.platformFeeMicros),
            microsToDecimal(charges.gstMicros),
            microsToDecimal(prepared.walletBefore),
            microsToDecimal(prepared.walletAfter),
            itemRecordId,
            `Ad spend for campaign ${ad.campaign_id} (${payload.platform})`,
          ],
        );

        if (prepared.walletAfter === 0n) {
          await pauseAllUserCampaignsForWallet(
            connection,
            ad.user_id,
            Number(payload.interval_end),
          );
        }
      }

      await connection.execute(
        `
          INSERT INTO ad_campaign_daily_spend (
            campaign_id,
            ad_id,
            user_id,
            business_id,
            wallet_id,
            platform,
            campaign_timezone,
            campaign_local_date,
            currency_code,
            impressions,
            clicks,
            impression_charge,
            click_charge,
            total_charge
          )
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)

          ON DUPLICATE KEY UPDATE
            impressions = impressions + VALUES(impressions),
            clicks = clicks + VALUES(clicks),
            impression_charge =
              impression_charge + VALUES(impression_charge),
            click_charge =
              click_charge + VALUES(click_charge),
            total_charge =
              total_charge + VALUES(total_charge),
            updated_at = CURRENT_TIMESTAMP
        `,
        [
          ad.campaign_id,
          prepared.ad_id,
          ad.user_id,
          ad.business_id,
          ad.wallet_id,
          payload.platform,
          ad.timezone,
          localDate,
          ad.currency_code,
          prepared.impressions,
          prepared.clicks,
          microsToDecimal(charges.impressionMicros),
          microsToDecimal(charges.clickMicros),
          microsToDecimal(charges.totalMicros),
        ],
      );

      const adIsDeleted = Number(ad.ad_is_deleted) === 1;

      if (!adIsDeleted) {
        if (prepared.lifetimeTotalAfter >= decimalToMicros(ad.total_budget)) {
          await completeCampaignForBudget(
            connection,
            ad.campaign_id,
            prepared.ad_id,
            Number(payload.interval_end),
          );
        } else if (
          ad.daily_budget !== null &&
          prepared.dailyTotalAfter >= decimalToMicros(ad.daily_budget)
        ) {
          await pauseCampaign(connection, {
            campaignId: ad.campaign_id,
            adId: prepared.ad_id,
            reason: "daily_budget",
            pausedAt: Number(payload.interval_end),
            resumeAt: getNextLocalMidnight(localDate, ad.timezone),
          });
        }
      }

      processedItems.push({
        ad_id: prepared.ad_id,
        impressions: prepared.impressions,
        clicks: prepared.clicks,
        impression_charge: microsToDecimal(charges.impressionMicros),
        click_charge: microsToDecimal(charges.clickMicros),
        total_charge: microsToDecimal(charges.totalMicros),
        platform_fee: microsToDecimal(charges.platformFeeMicros),
        gst_amount: microsToDecimal(charges.gstMicros),
        wallet_debit: microsToDecimal(charges.walletDebitMicros),
        currency: ad.currency_code,
      });
    }

    await connection.execute(
      `
        UPDATE ad_analytics_batches
        SET processed_at = CURRENT_TIMESTAMP
        WHERE id = ?
      `,
      [batchRecordId],
    );

    await connection.commit();

    return {
      duplicate: false,
      rejected: false,
      batch_id: payload.batch_id,
      batch_record_id: batchRecordId,
      platform: payload.platform,
      processed_items: processedItems,
      total_charge: microsToDecimal(totalBatchCharge),
      total_platform_fee: microsToDecimal(totalBatchPlatformFee),
      total_gst: microsToDecimal(totalBatchGst),
      total_wallet_debit: microsToDecimal(totalBatchWalletDebit),
      currency: processedItems[0]?.currency || "INR",
    };
  } catch (error) {
    try {
      await connection.rollback();
    } catch (rollbackError) {
      console.error("Analytics transaction rollback failed:", rollbackError);
    }

    if (error.code === "ER_DUP_ENTRY") {
      const existingBatch = await getExistingBatch(payload.batch_id);

      if (existingBatch && existingBatch.payload_hash === payloadHash) {
        return {
          duplicate: true,
          rejected: existingBatch.processing_status === "rejected",
          batch_id: payload.batch_id,
          rejection_reason: existingBatch.rejection_reason || null,
          message:
            existingBatch.processing_status === "rejected"
              ? "This analytics batch was previously rejected."
              : "This analytics batch was already processed.",
        };
      }

      throw createError(
        "This analytics interval or batch has already been processed.",
        409,
      );
    }

    throw error;
  } finally {
    connection.release();
  }
};
