const adSchema = {
  AdSubtypeResponse: {
    type: "object",
    properties: {
      id: {
        type: "integer",
        example: 1,
      },
      ad_type_id: {
        type: "integer",
        example: 1,
      },
      name: {
        type: "string",
        example: "Single Image",
      },
      code: {
        type: "string",
        example: "SINGLE_IMAGE",
      },
      description: {
        type: "string",
        nullable: true,
        example: "Advertisement using a single image.",
      },
      preview_image_url: {
        type: "string",
        nullable: true,
        example: "/uploads/ad-previews/single-image.png",
      },
      preview_description: {
        type: "string",
        nullable: true,
        example: "Preview of the single image ad subtype.",
      },
      sort_order: {
        type: "integer",
        example: 1,
      },
      is_active: {
        type: "integer",
        enum: [0, 1],
        example: 1,
      },
    },
  },

  AdTypeResponse: {
    type: "object",
    properties: {
      id: {
        type: "integer",
        example: 1,
      },
      name: {
        type: "string",
        example: "Image Ad",
      },
      code: {
        type: "string",
        example: "IMAGE",
      },
      description: {
        type: "string",
        nullable: true,
        example: "Engage with a single image.",
      },
      preview_image_url: {
        type: "string",
        nullable: true,
        description:
          "Default preview image URL or public path for this ad type.",
        example: "/uploads/ad-previews/banner.png",
      },
      preview_description: {
        type: "string",
        nullable: true,
        description: "Preview description for the ad type.",
        example: "Preview of the selected ad type.",
      },
      sort_order: {
        type: "integer",
        example: 1,
      },
      is_active: {
        type: "integer",
        enum: [0, 1],
        example: 1,
      },
      sub_types: {
        type: "array",
        description:
          "Active subtypes belonging to this ad type. Empty when no subtypes are available.",
        items: {
          $ref: "#/components/schemas/AdSubtypeResponse",
        },
      },
    },
  },

  AdObjectiveResponse: {
    type: "object",
    properties: {
      id: {
        type: "integer",
        example: 1,
      },
      name: {
        type: "string",
        example: "Increase Awareness",
      },
      description: {
        type: "string",
        nullable: true,
        example: "Build visibility for your brand or message.",
      },
      sort_order: {
        type: "integer",
        example: 1,
      },
      is_active: {
        type: "integer",
        enum: [0, 1],
        example: 1,
      },
      created_at: {
        type: "string",
        format: "date-time",
      },
      updated_at: {
        type: "string",
        format: "date-time",
      },
    },
  },

  AdResponse: {
    type: "object",
    properties: {
      id: {
        type: "integer",
        example: 15,
      },
      campaign_id: {
        type: "integer",
        nullable: true,
        example: null,
      },
      business_id: {
        type: "integer",
        example: 1,
      },
      objective_id: {
        type: "integer",
        example: 1,
      },
      ad_type_id: {
        type: "integer",
        example: 1,
      },
      ad_subtype_id: {
        type: "integer",
        nullable: true,
        description:
          "Selected subtype ID. Required when the selected ad type has active subtypes. Must belong to the selected ad type.",
        example: 1,
      },
      title: {
        type: "string",
        example: "Youth meeting",
      },
      description: {
        type: "string",
        example: "Join us for an exciting youth meeting.",
      },
      action_button_type_id: {
        type: "integer",
        nullable: true,
        example: 1,
      },
      destination_link: {
        type: "string",
        nullable: true,
        example: "https://example.com/reading",
      },
      platform: {
        type: "string",
        enum: ["android", "ios", "both"],
        example: "both",
      },
      status: {
        type: "string",
        example: "draft",
      },
      media_id: {
        type: "integer",
        nullable: true,
        example: 12,
      },
      media_type: {
        type: "string",
        nullable: true,
        enum: ["image", "video"],
        example: "image",
      },
      file_url: {
        type: "string",
        nullable: true,
        example: "/uploads/ads/example.jpg",
      },
      file_name: {
        type: "string",
        nullable: true,
        example: "example.jpg",
      },
      mime_type: {
        type: "string",
        nullable: true,
        example: "image/jpeg",
      },
      file_size: {
        type: "integer",
        nullable: true,
        example: 245678,
      },
    },
  },

  AdSingleResponse: {
    type: "object",
    properties: {
      success: {
        type: "boolean",
        example: true,
      },
      message: {
        type: "string",
        example: "Draft ad created successfully.",
      },
      data: {
        $ref: "#/components/schemas/AdResponse",
      },
    },
  },

  AdActionButtonResponse: {
    type: "object",
    properties: {
      id: {
        type: "integer",
        example: 1,
      },
      name: {
        type: "string",
        example: "Learn More",
      },
      code: {
        type: "string",
        example: "LEARN_MORE",
      },
      sort_order: {
        type: "integer",
        example: 1,
      },
      is_active: {
        type: "integer",
        enum: [0, 1],
        example: 1,
      },
      created_at: {
        type: "string",
        format: "date-time",
      },
      updated_at: {
        type: "string",
        format: "date-time",
      },
    },
  },

  GetAdTypesResponse: {
    type: "object",
    properties: {
      success: {
        type: "boolean",
        example: true,
      },
      data: {
        type: "array",
        items: {
          $ref: "#/components/schemas/AdTypeResponse",
        },
      },
    },
  },

  GetAdObjectivesResponse: {
    type: "object",
    properties: {
      success: {
        type: "boolean",
        example: true,
      },
      data: {
        type: "array",
        items: {
          $ref: "#/components/schemas/AdObjectiveResponse",
        },
      },
    },
  },

  GetAdActionButtonsResponse: {
    type: "object",
    properties: {
      success: {
        type: "boolean",
        example: true,
      },
      data: {
        type: "array",
        items: {
          $ref: "#/components/schemas/AdActionButtonResponse",
        },
      },
    },
  },
};

export default adSchema;