
const PLATFORM_FEE_PERCENT = 30;
const GST_PERCENT = 18;

export const decimalToMicros = (value) => {
  const text = String(value ?? "0").trim();
  const match = text.match(/^(-?)(\d+)(?:\.(\d{1,6}))?$/);

  if (!match) {
    throw new Error(`Invalid monetary value: ${text}`);
  }

  const sign = match[1] === "-" ? -1n : 1n;
  const fraction = (match[3] || "").padEnd(6, "0");

  return (
    sign *
    (BigInt(match[2]) * 1000000n + BigInt(fraction || "0"))
  );
};

const decimalToCents = (value) => {
  const text = String(value ?? "0").trim();
  const match = text.match(/^(\d+)(?:\.(\d{1,2}))?$/);

  if (!match) {
    throw new Error(`Invalid pricing rate: ${text}`);
  }

  return (
    BigInt(match[1]) * 100n +
    BigInt((match[2] || "").padEnd(2, "0") || "0")
  );
};

export const microsToDecimal = (value) => {
  const negative = value < 0n;
  const absolute = negative ? -value : value;

  const whole = absolute / 1000000n;
  const fraction = String(absolute % 1000000n).padStart(6, "0");

  return `${negative ? "-" : ""}${whole}.${fraction}`;
};

export const calculatePercentageMicros = (amountMicros, percentage) => {
  if (typeof amountMicros !== "bigint" || amountMicros < 0n) {
    throw new Error("Amount must be a non-negative BigInt.");
  }

  if (!Number.isFinite(Number(percentage)) || Number(percentage) < 0) {
    throw new Error("Percentage must be a non-negative number.");
  }

  const basisPoints = BigInt(
    Math.round(Number(percentage) * 100),
  );

  return (amountMicros * basisPoints + 5000n) / 10000n;
};

const calculateAdSpend = ({
  impressions,
  clicks,
  cpmRate,
  cpcRate,
  platformFeePercent = PLATFORM_FEE_PERCENT,
  gstPercent = GST_PERCENT,
}) => {
  const impressionText = String(impressions);
  const clickText = String(clicks);

  if (!/^\d+$/.test(impressionText) || !/^\d+$/.test(clickText)) {
    throw new Error("Impressions and clicks must be non-negative integers.");
  }

  const cpmCents = decimalToCents(cpmRate);
  const cpcCents = decimalToCents(cpcRate);

  const impressionCount = BigInt(impressionText);
  const clickCount = BigInt(clickText);

  const impressionMicros = impressionCount * cpmCents * 10n;
  const clickMicros = clickCount * cpcCents * 10000n;

  const totalMicros = impressionMicros + clickMicros;

  const platformFeeMicros = calculatePercentageMicros(
    totalMicros,
    platformFeePercent,
  );

  const gstMicros = calculatePercentageMicros(
    totalMicros,
    gstPercent,
  );

  const walletDebitMicros =
    totalMicros + platformFeeMicros + gstMicros;

  return {
    impressionMicros,
    clickMicros,
    totalMicros,
    platformFeeMicros,
    gstMicros,
    walletDebitMicros,
  };
};

export {
  calculateAdSpend,
  PLATFORM_FEE_PERCENT,
  GST_PERCENT,
};
