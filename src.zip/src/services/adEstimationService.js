import AD_ESTIMATION_CONFIG from "../configs/ads/adEstimationConfig.js";

const roundEstimate = (value) => Math.max(0, Math.round(value));

const estimateAdPerformance = ({
  objectiveId,
  adTypeId,
  mediaType,
  totalBudget,
}) => {
  const adTypeConfig = AD_ESTIMATION_CONFIG.adTypes[Number(adTypeId)];
  const objectiveConfig = AD_ESTIMATION_CONFIG.objectives[Number(objectiveId)];

  if (!adTypeConfig || !objectiveConfig) {
    throw new Error("Estimation configuration not found.");
  }

  const mediaConfig = adTypeConfig[mediaType];

  if (!mediaConfig) {
    throw new Error("Invalid ad media type for estimation.");
  }

  const budget = Number(totalBudget);

  if (!Number.isFinite(budget) || budget <= 0) {
    throw new Error("Invalid campaign budget for estimation.");
  }

  const adjustedCpm = mediaConfig.cpm * objectiveConfig.cpmMultiplier;

  const estimatedImpressions = (budget / adjustedCpm) * 1000;

  const estimatedReach = estimatedImpressions / mediaConfig.frequency;

  const estimatedViews =
    mediaType === "video" ? estimatedImpressions * mediaConfig.viewRate : null;

  return {
    currency: AD_ESTIMATION_CONFIG.currency,
    media_type: mediaType,
    estimated_impressions: roundEstimate(estimatedImpressions),
    estimated_reach: roundEstimate(estimatedReach),
    estimated_views:
      estimatedViews === null ? null : roundEstimate(estimatedViews),
    assumptions: {
      estimated_cpm: Number(adjustedCpm.toFixed(2)),
      average_frequency: mediaConfig.frequency,
      video_view_rate: mediaType === "video" ? mediaConfig.viewRate : null,
    },
  };
};

export default estimateAdPerformance;
